import http.server
import socketserver
import json
import urllib.request
import urllib.parse
import threading
import time
import os
import sys
import io

if sys.platform == 'win32':
    try:
        sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
        sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')
    except Exception:
        pass

PORT = 8080

DB_FILE = "portfolio_db.json"
CONFIG_FILE = "telegram_config.json"
ML_DB_FILE = "ml_performance_db.json"

state = {
    "balance": 10000.0,
    "positions": [],
    "history": [],
    "auto_pilot": True,
    "symbols": ["BTCUSDT", "ETHUSDT", "SOLUSDT", "AVAXUSDT", "BNBUSDT", "NEARUSDT", "LINKUSDT", "XRPUSDT", "DOGEUSDT", "SUIUSDT"],
    "ticker_data": {},
    "klines_data": {}
}

# 🧠 Self-Learning Adaptive Machine Learning Weights
ml_weights = {
    "pattern_weights": {
        "İkili Dip (W-Formasyonu)": 1.15,
        "Boğa Bayrağı (Bull Flag)": 1.10,
        "İkili Tepe (M-Formasyonu)": 1.08,
        "Kanal İçi Akümülasyon": 0.95
    },
    "rsi_threshold_long": 36,
    "rsi_threshold_short": 64,
    "total_learnings": 0,
    "win_streak": 0,
    "loss_streak": 0
}

telegram_config = {
    "bot_token": "",
    "chat_id": "",
    "enabled": False
}

def load_db():
    global state, telegram_config, ml_weights
    if os.path.exists(DB_FILE):
        try:
            with open(DB_FILE, 'r', encoding='utf-8') as f:
                saved = json.load(f)
                state.update(saved)
        except Exception as e:
            print("DB load error:", e)
    
    if os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE, 'r', encoding='utf-8') as f:
                telegram_config.update(json.load(f))
        except Exception as e:
            print("Telegram config load error:", e)

    if os.path.exists(ML_DB_FILE):
        try:
            with open(ML_DB_FILE, 'r', encoding='utf-8') as f:
                saved_ml = json.load(f)
                ml_weights.update(saved_ml)
        except Exception as e:
            print("ML DB load error:", e)

def save_db():
    try:
        with open(DB_FILE, 'w', encoding='utf-8') as f:
            json.dump({
                "balance": state["balance"],
                "positions": state["positions"],
                "history": state["history"],
                "auto_pilot": state["auto_pilot"]
            }, f, indent=2)
    except Exception as e:
        print("DB save error:", e)

def save_ml_db():
    try:
        with open(ML_DB_FILE, 'w', encoding='utf-8') as f:
            json.dump(ml_weights, f, indent=2)
    except Exception as e:
        print("ML DB save error:", e)

def save_telegram_config():
    try:
        with open(CONFIG_FILE, 'w', encoding='utf-8') as f:
            json.dump(telegram_config, f, indent=2)
    except Exception as e:
        print("Telegram config save error:", e)

MAIN_REPLY_KEYBOARD = {
    "keyboard": [
        [{"text": "📊 Açık Pozisyonlar"}, {"text": "💰 Toplam Kar/Zarar"}],
        [{"text": "🤖 Bot Durumu"}, {"text": "📱 Ana Menü"}]
    ],
    "resize_keyboard": True,
    "is_persistent": True
}

def send_telegram_message(text, reply_markup=None):
    if not telegram_config.get("enabled") or not telegram_config.get("bot_token") or not telegram_config.get("chat_id"):
        return False, "Bot Token veya Chat ID eksik."
    
    try:
        token = telegram_config["bot_token"].strip()
        chat_id = telegram_config["chat_id"].strip()
        url = f"https://api.telegram.org/bot{token}/sendMessage"
        
        payload_dict = {
            "chat_id": chat_id,
            "text": text,
            "parse_mode": "Markdown"
        }
        if reply_markup is None:
            reply_markup = MAIN_REPLY_KEYBOARD
            
        payload_dict["reply_markup"] = json.dumps(reply_markup)
        
        payload = urllib.parse.urlencode(payload_dict).encode('utf-8')
        
        req = urllib.request.Request(url, data=payload, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(req, timeout=8) as resp:
            body = json.loads(resp.read().decode('utf-8'))
            if body.get("ok"):
                return True, "Başarılı"
            else:
                return False, body.get("description", "Bilinmeyen hata")
    except Exception as e:
        return False, f"Bağlantı Hatası: {str(e)}"

def set_telegram_commands():
    if not telegram_config.get("enabled") or not telegram_config.get("bot_token"):
        return
    try:
        token = telegram_config["bot_token"].strip()
        url = f"https://api.telegram.org/bot{token}/setMyCommands"
        commands = [
            {"command": "pozisyonlar", "description": "📊 Açık pozisyonlar ve anlık PnL"},
            {"command": "pnl", "description": "💰 Toplam kâr/zarar ve portföy özeti"},
            {"command": "durum", "description": "🤖 Bot canlı durumu ve YZ ayarları"},
            {"command": "menu", "description": "📱 Ana menü butonlarını gösterir"}
        ]
        payload = urllib.parse.urlencode({"commands": json.dumps(commands)}).encode('utf-8')
        req = urllib.request.Request(url, data=payload, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(req, timeout=5) as resp:
            pass
    except Exception as e:
        print("setMyCommands error:", e)

def handle_telegram_command(cmd_text, chat_id):
    cmd = cmd_text.lower().strip()
    
    if "açık pozisyon" in cmd or cmd in ["/pozisyonlar", "/pozisyon", "pozisyonlar"]:
        positions = state.get("positions", [])
        if not positions:
            send_telegram_message("ℹ️ *Şu anda aktif açık pozisyon bulunmamaktadır.*")
            return
        
        lines = [f"📊 *AKTİF AÇIK POZİSYONLAR ({len(positions)})*", "---------------------------------"]
        for p in positions:
            sym = p.get("symbol", "N/A")
            side = p.get("side", "LONG")
            entry = format_price(p.get("entryPrice", 0))
            mark = format_price(p.get("markPrice", p.get("entryPrice", 0)))
            pnl = p.get("pnl", 0)
            pnl_pct = p.get("pnlPercent", 0)
            tp1 = format_price(p.get("tp1", 0))
            sl = format_price(p.get("sl", 0))
            
            pnl_icon = "🟢" if pnl >= 0 else "🔴"
            pnl_str = f"{pnl_icon} *${pnl:+.2f} ({pnl_pct:+.2f}%)*"
            
            lines.append(
                f"• *{sym}* ({side})\n"
                f"  └ Giriş: `{entry}` | Mark: `{mark}`\n"
                f"  └ Kar/Zarar: {pnl_str}\n"
                f"  └ Hedef (TP1): `{tp1}` | Stop (SL): `{sl}`"
            )
            lines.append("---------------------------------")
            
        msg = "\n".join(lines)
        send_telegram_message(msg)
        
    elif "kar/zarar" in cmd or "kâr/zarar" in cmd or "pnl" in cmd or cmd in ["/pnl", "pnl", "/kar"]:
        history = state.get("history", [])
        closed_count = len(history)
        realized_pnl = sum(h.get("pnl", 0) for h in history)
        wins = sum(1 for h in history if h.get("pnl", 0) > 0)
        losses = sum(1 for h in history if h.get("pnl", 0) <= 0)
        win_rate = (wins / closed_count * 100) if closed_count > 0 else 0.0
        
        unrealized_pnl = sum(p.get("pnl", 0) for p in state.get("positions", []))
        total_pnl = realized_pnl + unrealized_pnl
        balance = state.get("balance", 10000.0)
        equity = balance + sum((p.get("entryPrice", 0) * p.get("size", 0)) + p.get("pnl", 0) for p in state.get("positions", []))
        
        realized_icon = "📈" if realized_pnl >= 0 else "📉"
        unrealized_icon = "🟢" if unrealized_pnl >= 0 else "🔴"
        total_icon = "🚀" if total_pnl >= 0 else "⚠️"
        
        msg = (
            f"💰 *TOPLAM PORTFÖY & KÂR/ZARAR ÖZETİ*\n\n"
            f"💵 Kullanılabilir Bakiye: `${balance:,.2f} USDT`\n"
            f"📊 Toplam Portföy Değeri: `${equity:,.2f} USDT`\n"
            f"---------------------------------\n"
            f"{realized_icon} Realize Edilmiş Net PnL (Kapanan): *${realized_pnl:+.2f} USDT*\n"
            f"{unrealized_icon} Açık Pozisyonlar Anlık PnL: *${unrealized_pnl:+.2f} USDT*\n"
            f"{total_icon} *GENEL TOPLAM PnL:* *${total_pnl:+.2f} USDT*\n"
            f"---------------------------------\n"
            f"🎯 *İşlem İstatistikleri:*\n"
            f"• Kapanan İşlem Sayısı: `{closed_count}`\n"
            f"• Başarılı (Kar): `{wins}` ✅\n"
            f"• Stop (Zarar): `{losses}` 🛑\n"
            f"• Kazanma Oranı (Win Rate): *%{win_rate:.1f}*"
        )
        send_telegram_message(msg)
        
    elif "durum" in cmd or cmd in ["/durum", "durum"]:
        auto_st = "ETKİN (ON) ⚡" if state.get("auto_pilot") else "PASİF (OFF) ⏸️"
        msg = (
            f"🤖 *QUANTUM AI BOT CANLI DURUMU*\n\n"
            f"⚡ Otomatik Pilot: *{auto_st}*\n"
            f"🧠 Toplam YZ Öğrenimi: `{ml_weights.get('total_learnings', 0)}`\n"
            f"🔥 Galibiyet Serisi: `{ml_weights.get('win_streak', 0)}`\n"
            f"🛑 Mağlubiyet Serisi: `{ml_weights.get('loss_streak', 0)}`\n"
            f"🎯 RSI Eşikleri: Long `<{ml_weights.get('rsi_threshold_long', 36)}` | Short `>{ml_weights.get('rsi_threshold_short', 64)}`"
        )
        send_telegram_message(msg)
        
    elif cmd in ["/start", "/menu", "menü", "menu"]:
        send_telegram_message(
            "📱 *Quantum AI Bot Menüsü*\n\nAşağıdaki butonları kullanarak bakiye, kar/zarar ve açık pozisyon durumunu anlık takip edebilirsiniz.",
            reply_markup=MAIN_REPLY_KEYBOARD
        )

def telegram_listener_loop():
    print("📱 Telegram Interactive Command Listener Loop Running...")
    time.sleep(3)
    set_telegram_commands()
    last_update_id = 0
    while True:
        if not telegram_config.get("enabled") or not telegram_config.get("bot_token"):
            time.sleep(5)
            continue
        try:
            token = telegram_config["bot_token"].strip()
            url = f"https://api.telegram.org/bot{token}/getUpdates?offset={last_update_id + 1}&timeout=10"
            req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
            with urllib.request.urlopen(req, timeout=12) as resp:
                data = json.loads(resp.read().decode('utf-8'))
                if data.get("ok"):
                    for update in data.get("result", []):
                        last_update_id = update["update_id"]
                        message = update.get("message", {})
                        text = message.get("text", "").strip()
                        chat = message.get("chat", {})
                        chat_id = str(chat.get("id", ""))
                        
                        if text:
                            handle_telegram_command(text, chat_id)
        except Exception:
            pass
        time.sleep(2)

def format_price(val):
    try:
        v = float(val)
        if v >= 1000:
            return f"${v:,.2f}"
        elif v >= 1:
            return f"${v:,.4f}"
        else:
            return f"${v:,.6f}"
    except Exception:
        return f"${val}"

# 🧠 Self-Learning Reinforcement Module
def update_self_learning_engine(closed_pos):
    pnl = closed_pos.get("pnl", 0)
    pattern = closed_pos.get("patternName", "Kanal İçi Akümülasyon")
    
    ml_weights["total_learnings"] += 1

    if pnl > 0:
        ml_weights["win_streak"] += 1
        ml_weights["loss_streak"] = 0
        current_w = ml_weights["pattern_weights"].get(pattern, 1.0)
        ml_weights["pattern_weights"][pattern] = min(1.35, round(current_w + 0.02, 2))
        learning_msg = f"🧠 *YZ ÖĞRENME MOTORU*: {closed_pos['symbol']} işleminde Kar ($+{pnl:.2f}) elde edildi. *{pattern}* formasyonunun başarı ağırlığı artırıldı ({ml_weights['pattern_weights'][pattern]}x)."
    else:
        ml_weights["loss_streak"] += 1
        ml_weights["win_streak"] = 0
        current_w = ml_weights["pattern_weights"].get(pattern, 1.0)
        ml_weights["pattern_weights"][pattern] = max(0.80, round(current_w - 0.03, 2))
        
        if closed_pos.get("side") == "LONG":
            ml_weights["rsi_threshold_long"] = max(30, ml_weights["rsi_threshold_long"] - 1)
        else:
            ml_weights["rsi_threshold_short"] = min(70, ml_weights["rsi_threshold_short"] + 1)
            
        learning_msg = f"🧠 *YZ ÖĞRENME MOTORU (Adaptif Ayar)*: {closed_pos['symbol']} işleminde Zarar (${pnl:.2f}) analiz edildi. Risk eşiği daha muhafazakar seviyeye (RSI Long: <{ml_weights['rsi_threshold_long']}) çekildi."

    save_ml_db()
    send_telegram_message(learning_msg)

# Python Technical Indicators
def calculate_python_indicators(prices):
    if not prices or len(prices) < 14:
        return None
    
    current_price = prices[-1]
    
    gains, losses = 0, 0
    for i in range(len(prices) - 14, len(prices)):
        diff = prices[i] - prices[i - 1]
        if diff >= 0:
            gains += diff
        else:
            losses += abs(diff)
    avg_gain = gains / 14.0
    avg_loss = losses / 14.0
    rs = 100.0 if avg_loss == 0 else avg_gain / avg_loss
    rsi = 100.0 - (100.0 / (1.0 + rs))

    ema20 = current_price
    ema50 = current_price
    if len(prices) >= 20:
        ema20 = sum(prices[-20:]) / 20.0
    if len(prices) >= 50:
        ema50 = sum(prices[-50:]) / 50.0

    recent = prices[-60:] if len(prices) >= 60 else prices
    swing_low = min(recent)
    swing_high = max(recent)

    return {
        "currentPrice": current_price,
        "rsi": rsi,
        "ema20": ema20,
        "ema50": ema50,
        "support": swing_low,
        "resistance": swing_high
    }

symbol_cooldowns = {}

def calc_tp_sl(price, side, supp, resis):
    decimals = 2 if price >= 1000 else (4 if price >= 1 else 6)
    if side == "LONG":
        tp1 = round(max(price * 1.018, resis * 1.002 if resis > price else price * 1.018), decimals)
        sl = round(min(price * 0.985, supp * 0.998 if supp < price else price * 0.985), decimals)
        if tp1 <= price:
            tp1 = round(price * 1.018, decimals)
        if sl >= price:
            sl = round(price * 0.985, decimals)
    else: # SHORT
        tp1 = round(min(price * 0.982, supp * 0.998 if supp < price else price * 0.982), decimals)
        sl = round(max(price * 1.015, resis * 1.002 if resis > price else price * 1.015), decimals)
        if tp1 >= price:
            tp1 = round(price * 0.982, decimals)
        if sl <= price:
            sl = round(price * 1.015, decimals)
    return tp1, sl

# 24/7 Background Trading & Self-Learning Auto-Pilot Loop
def background_bot_loop():
    print("🧠 24/7 Quantum AI Self-Learning Engine Running...")
    last_auto_scan = 0

    while True:
        try:
            # 1. Fetch Real Binance Tickers
            url = "https://data-api.binance.vision/api/v3/ticker/24hr"
            req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'})
            try:
                with urllib.request.urlopen(req, timeout=6) as response:
                    data = json.loads(response.read().decode('utf-8'))
                    for item in data:
                        sym = item.get("symbol")
                        if sym in state["symbols"]:
                            state["ticker_data"][sym] = {
                                "symbol": sym,
                                "price": float(item.get("lastPrice", 0)),
                                "change24h": float(item.get("priceChangePercent", 0))
                            }
            except Exception:
                pass

            # 2. Update Mark Prices & Check TP/SL Triggers with Reinforcement Learning
            positions_to_keep = []
            for pos in state["positions"]:
                sym_clean = pos["symbol"].replace("/", "")
                mark_price = state["ticker_data"].get(sym_clean, {}).get("price", pos["entryPrice"])
                pos["markPrice"] = mark_price
                
                if pos["side"] == "LONG":
                    pos["pnl"] = (mark_price - pos["entryPrice"]) * pos["size"]
                    pos["pnlPercent"] = ((mark_price - pos["entryPrice"]) / pos["entryPrice"]) * 100
                else:
                    pos["pnl"] = (pos["entryPrice"] - mark_price) * pos["size"]
                    pos["pnlPercent"] = ((pos["entryPrice"] - mark_price) / pos["entryPrice"]) * 100
                
                triggered = False
                trigger_type = ""
                if pos["side"] == "LONG":
                    if mark_price >= pos["tp1"]:
                        triggered = True
                        trigger_type = "🎯 KAR AL 1 (TP1) TETİKLENDİ!"
                    elif mark_price <= pos["sl"]:
                        triggered = True
                        trigger_type = "🛑 STOP LOSS (SL) TETİKLENDİ!"
                elif pos["side"] == "SHORT":
                    if mark_price <= pos["tp1"]:
                        triggered = True
                        trigger_type = "🎯 KAR AL 1 (TP1) TETİKLENDİ!"
                    elif mark_price >= pos["sl"]:
                        triggered = True
                        trigger_type = "🛑 STOP LOSS (SL) TETİKLENDİ!"
                
                if triggered:
                    return_amount = (pos["entryPrice"] * pos["size"]) + pos["pnl"]
                    state["balance"] += return_amount
                    hist_entry = dict(pos)
                    hist_entry["closeReason"] = trigger_type
                    hist_entry["closeTime"] = time.strftime("%H:%M:%S")
                    state["history"].insert(0, hist_entry)
                    symbol_cooldowns[pos["symbol"]] = time.time()
                    save_db()
                    
                    # Telegram Alert for Closed Trade
                    msg = (
                        f"{trigger_type}\n"
                        f"• Varlık: *{pos['symbol']}* ({pos['side']})\n"
                        f"• Giriş Fiyatı: `{format_price(pos['entryPrice'])}`\n"
                        f"• Kapanış Fiyatı: `{format_price(mark_price)}`\n"
                        f"• Kar/Zarar: *${pos['pnl']:+.2f} ({pos['pnlPercent']:+.2f}%)*"
                    )
                    send_telegram_message(msg)

                    # 🧠 Trigger Self-Learning Machine Learning Engine
                    update_self_learning_engine(hist_entry)
                else:
                    positions_to_keep.append(pos)
            
            state["positions"] = positions_to_keep

            # 3. 🧠 24/7 SELF-LEARNING AUTO-PILOT ENGINE
            now = time.time()
            if state["auto_pilot"] and (now - last_auto_scan > 15) and state["balance"] >= 1000:
                last_auto_scan = now
                
                for sym in state["symbols"]:
                    clean_display_sym = sym.replace("USDT", "/USDT")
                    already_open = any(p["symbol"] == clean_display_sym for p in state["positions"])
                    if already_open:
                        continue

                    # 15-minute cooldown per symbol to prevent rapid trade spamming
                    last_tr_time = symbol_cooldowns.get(clean_display_sym, 0)
                    if (now - last_tr_time) < 900:
                        continue

                    try:
                        k_url = f"https://data-api.binance.vision/api/v3/klines?symbol={sym}&interval=15m&limit=100"
                        req_k = urllib.request.Request(k_url, headers={'User-Agent': 'Mozilla/5.0'})
                        with urllib.request.urlopen(req_k, timeout=4) as r_k:
                            k_data = json.loads(r_k.read().decode('utf-8'))
                            p_series = [float(c[4]) for c in k_data]
                            ind = calculate_python_indicators(p_series)

                            if ind:
                                current_price = ind["currentPrice"]
                                rsi = ind["rsi"]
                                ema20 = ind["ema20"]
                                ema50 = ind["ema50"]
                                supp = ind["support"]
                                resis = ind["resistance"]

                                # Dynamic Adaptive Thresholds from ML Weights
                                rsi_long_limit = ml_weights.get("rsi_threshold_long", 36)
                                rsi_short_limit = ml_weights.get("rsi_threshold_short", 64)

                                should_open = False
                                side = "LONG"
                                confidence = 88

                                # Strong technical entry signals
                                if rsi < rsi_long_limit:
                                    should_open = True
                                    side = "LONG"
                                    confidence = 92
                                elif ema20 > ema50 and 38 <= rsi <= 52 and current_price >= ema20:
                                    should_open = True
                                    side = "LONG"
                                    confidence = 88
                                elif rsi > rsi_short_limit:
                                    should_open = True
                                    side = "SHORT"
                                    confidence = 90
                                elif ema20 < ema50 and 48 <= rsi <= 62 and current_price <= ema20:
                                    should_open = True
                                    side = "SHORT"
                                    confidence = 87

                                if should_open and confidence >= 87:
                                    amount = 1000.0
                                    size = round(amount / current_price, 4)
                                    
                                    tp1, sl = calc_tp_sl(current_price, side, supp, resis)

                                    pos = {
                                        "id": "AUTO-" + str(int(time.time()))[-6:],
                                        "symbol": clean_display_sym,
                                        "side": side,
                                        "size": size,
                                        "entryPrice": current_price,
                                        "markPrice": current_price,
                                        "tp1": tp1,
                                        "sl": sl,
                                        "pnl": 0.0,
                                        "pnlPercent": 0.0,
                                        "patternName": "İkili Dip (W-Formasyonu)" if side == "LONG" else "İkili Tepe (M-Formasyonu)",
                                        "timestamp": time.strftime("%H:%M:%S")
                                    }

                                    state["balance"] -= amount
                                    state["positions"].append(pos)
                                    symbol_cooldowns[clean_display_sym] = time.time()
                                    save_db()

                                    # Telegram Alert for ML Auto-Pilot Trade
                                    msg = (
                                        f"🤖 *KENDİ KENDİNE ÖĞRENEN YZ İŞLEM AÇTI!* (%{confidence} Güven)\n"
                                        f"• Varlık: *{pos['symbol']}* ({pos['side']})\n"
                                        f"• Giriş Fiyatı: `{format_price(pos['entryPrice'])}`\n"
                                        f"• Hedef (TP1): `{format_price(pos['tp1'])}`\n"
                                        f"• Stop-Loss (SL): `{format_price(pos['sl'])}`\n"
                                        f"• Öğrenilmiş ML Skoru: *{ml_weights['pattern_weights'].get(pos['patternName'], 1.0)}x*"
                                    )
                                    send_telegram_message(msg)
                                    break
                    except Exception as e_k:
                        print("Auto-pilot kline scan error:", e_k)

        except Exception as e:
            print("Background loop tick error:", e)

        time.sleep(3)

# Web Server & REST API Handler
class CustomHandler(http.server.SimpleHTTPRequestHandler):
    def do_GET(self):
        if self.path == "/api/state":
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            resp_data = {
                "balance": state["balance"],
                "positions": state["positions"],
                "history": state["history"],
                "auto_pilot": state["auto_pilot"],
                "ticker_data": state["ticker_data"],
                "ml_weights": ml_weights,
                "telegram_enabled": telegram_config.get("enabled", False)
            }
            self.wfile.write(json.dumps(resp_data).encode('utf-8'))
            return
        
        if self.path.startswith("/api/klines"):
            parsed = urllib.parse.urlparse(self.path)
            params = urllib.parse.parse_qs(parsed.query)
            sym = params.get("symbol", ["BTCUSDT"])[0]
            interval = params.get("interval", ["15m"])[0]
            limit = params.get("limit", ["100"])[0]
            
            try:
                k_url = f"https://data-api.binance.vision/api/v3/klines?symbol={sym}&interval={interval}&limit={limit}"
                req_k = urllib.request.Request(k_url, headers={'User-Agent': 'Mozilla/5.0'})
                with urllib.request.urlopen(req_k, timeout=5) as r_k:
                    body = r_k.read()
                    self.send_response(200)
                    self.send_header('Content-type', 'application/json')
                    self.send_header('Access-Control-Allow-Origin', '*')
                    self.end_headers()
                    self.wfile.write(body)
                    return
            except Exception:
                try:
                    k_url = f"https://api.binance.com/api/v3/klines?symbol={sym}&interval={interval}&limit={limit}"
                    req_k = urllib.request.Request(k_url, headers={'User-Agent': 'Mozilla/5.0'})
                    with urllib.request.urlopen(req_k, timeout=5) as r_k:
                        body = r_k.read()
                        self.send_response(200)
                        self.send_header('Content-type', 'application/json')
                        self.send_header('Access-Control-Allow-Origin', '*')
                        self.end_headers()
                        self.wfile.write(body)
                        return
                except Exception as e:
                    self.send_response(500)
                    self.send_header('Content-type', 'application/json')
                    self.end_headers()
                    self.wfile.write(json.dumps({"error": str(e)}).encode('utf-8'))
                    return

        return http.server.SimpleHTTPRequestHandler.do_GET(self)

    def do_POST(self):
        content_len = int(self.headers.get('Content-Length', 0))
        post_body = self.rfile.read(content_len).decode('utf-8') if content_len > 0 else "{}"
        data = json.loads(post_body) if post_body else {}

        if self.path == "/api/save-telegram":
            telegram_config["bot_token"] = data.get("bot_token", "")
            telegram_config["chat_id"] = data.get("chat_id", "")
            telegram_config["enabled"] = bool(data.get("enabled", False))
            save_telegram_config()
            
            ok, msg = True, "Ayarlar kaydedildi."
            if telegram_config["enabled"]:
                ok, msg = send_telegram_message("✅ *Quantum AI Bot Telegram Entegrasyonu Etkinleşti!* 7/24 canlı bildirimler bu kanala gönderilecektir.")

            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.end_headers()
            self.wfile.write(json.dumps({"success": ok, "message": msg}).encode('utf-8'))
            return

        elif self.path == "/api/open-trade":
            signal = data.get("signal", {})
            amount = float(data.get("amount", 1000))
            if state["balance"] >= amount and signal:
                side = "LONG" if signal.get("side") == "BUY" else "SHORT"
                entry_price = float(signal.get("entryPrice", 0))
                size = round(amount / entry_price, 4) if entry_price > 0 else 0
                
                pos = {
                    "id": "POS-" + str(int(time.time()))[-6:],
                    "symbol": signal.get("symbol", "BTC/USDT"),
                    "side": side,
                    "size": size,
                    "entryPrice": entry_price,
                    "markPrice": entry_price,
                    "tp1": float(signal.get("tp1", 0)),
                    "sl": float(signal.get("sl", 0)),
                    "pnl": 0.0,
                    "pnlPercent": 0.0,
                    "patternName": signal.get("patternName", "Manuel İşlem"),
                    "timestamp": time.strftime("%H:%M:%S")
                }
                state["balance"] -= amount
                state["positions"].append(pos)
                save_db()

                # Telegram Alert for Manual Trade
                msg = (
                    f"🚀 *MANUEL İŞLEM AÇILDI!*\n"
                    f"• Varlık: *{pos['symbol']}* ({pos['side']})\n"
                    f"• Giriş Fiyatı: `${pos['entryPrice']:,.2f}`\n"
                    f"• Hedef (TP1): `${pos['tp1']:,.2f}`\n"
                    f"• Stop-Loss (SL): `${pos['sl']:,.2f}`\n"
                    f"• Bakiye: `${state['balance']:,.2f} USDT`"
                )
                send_telegram_message(msg)

                self.send_response(200)
                self.send_header('Content-type', 'application/json')
                self.end_headers()
                self.wfile.write(json.dumps({"success": True, "position": pos}).encode('utf-8'))
                return

        elif self.path == "/api/toggle-autopilot":
            state["auto_pilot"] = bool(data.get("enabled", False))
            save_db()
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.end_headers()
            self.wfile.write(json.dumps({"success": True, "auto_pilot": state["auto_pilot"]}).encode('utf-8'))
            return

        self.send_response(404)
        self.end_headers()

def keep_alive_loop():
    url = os.environ.get("RENDER_EXTERNAL_URL", "https://quantum-ai-bot.onrender.com/")
    while True:
        time.sleep(240) # Every 4 minutes
        try:
            req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) KeepAlive'})
            with urllib.request.urlopen(req, timeout=10) as resp:
                pass
        except Exception as e:
            pass

if __name__ == "__main__":
    load_db()
    t = threading.Thread(target=background_bot_loop, daemon=True)
    t.start()
    
    t_keep = threading.Thread(target=keep_alive_loop, daemon=True)
    t_keep.start()
    
    t_tg = threading.Thread(target=telegram_listener_loop, daemon=True)
    t_tg.start()
    
    socketserver.TCPServer.allow_reuse_address = True
    with socketserver.TCPServer(("", PORT), CustomHandler) as httpd:
        print(f"🧠 Quantum AI 24/7 Self-Learning Server Running on Port {PORT}...")
        httpd.serve_forever()

